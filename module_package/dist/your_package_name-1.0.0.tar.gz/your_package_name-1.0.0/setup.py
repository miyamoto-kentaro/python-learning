from distutils.core import setup

setup(
    name='your_package_name',
    version='1.0.0',
    packages=['lesson_package','lesson_package.talk','lesson_package.tools'],
    url='your_url',
    author='your_name',
    author_email='your_email',
    description='your descriptions'
)