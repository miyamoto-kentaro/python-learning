from ..tools import utils

def sing():
    return utils.say_twice('aaawfgwgaewafa')

def cray():
    return utils.say_twice('wgagewaefaga')