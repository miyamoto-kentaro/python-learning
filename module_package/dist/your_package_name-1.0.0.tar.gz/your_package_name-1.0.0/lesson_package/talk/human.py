from ..tools import utils

def sing():
    return utils.say_twice('cray')

def cray():
    return utils.say_twice('cray')